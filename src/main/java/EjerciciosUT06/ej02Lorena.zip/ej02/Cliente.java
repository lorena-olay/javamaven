package EjerciciosUT06.ej02;

public class Cliente {
}
