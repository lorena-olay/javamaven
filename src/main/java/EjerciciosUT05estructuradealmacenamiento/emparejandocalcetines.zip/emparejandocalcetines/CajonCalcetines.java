package ut05estructuradealmacenamiento.emparejandocalcetines;


import java.util.*;

public class CajonCalcetines {

    public static void creadorCalcetines(){

        Random rand = new Random();
        ArrayList<String> lote1 = new ArrayList<String>();
        ArrayList<String> lote2 = new ArrayList<String>();
        /*
/*
        //int randomNum = rand.nextInt((20 - 10) + 1) + 10;
        int[] anArray = new int[10];


        //String random =String.valueOf(randomNum);
        for(int i = 0; i<.length();i++){
            Calcetin.crearCalcetin();
        }

         */
        //me he rayado mucho y al final era bastante fácil
        for (int i = 0 ; i < rand.nextInt((20 - 10) + 1) + 10; i++ ){
            //System.out.println(Calcetin.crearCalcetin());
            lote1.add(Calcetin.crearCalcetin());
            //list = Calcetin.crearCalcetin();

        }
        for (int i = 0 ; i < rand.nextInt((20 - 10) + 1) + 10; i++ ){
            //System.out.println(Calcetin.crearCalcetin());
            lote2.add(Calcetin.crearCalcetin());
            //list = Calcetin.crearCalcetin();

        }

        if (lote1.equals(lote2)){
            System.out.println("EMPAREJADOS");
        }else {
            System.out.println("DESEMPAREJADOS");
            String aux = String.valueOf(lote1.contains(lote2));
            lote1.remove(aux);
            lote2.remove(aux);
            System.out.println(lote1);
            System.out.println("*********************");
            System.out.println(lote2);
        }


    }




}
