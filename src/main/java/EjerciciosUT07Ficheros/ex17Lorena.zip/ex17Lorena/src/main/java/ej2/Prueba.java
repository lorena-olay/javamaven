package ej2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Prueba {
    public static void main(String[] args) throws FileNotFoundException {
        Lectura.leer("./escaleraColor.txt");
    }
}
