package ej1;

public enum Palos {
    PICAS,
    ROMBOS,
    TREBOLES,
    CORAZONES;

    Palos() {
    }
}
