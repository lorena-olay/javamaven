package ut05estructuradealmacenamiento.emparejandocalcetines;

public class Programa {
    public static void main(String[] args) {
        /*
        Calcetin.Colores c1 = Calcetin.Colores.GRISCLARO;
        Calcetin.Tallas c2 = Calcetin.Tallas.CUARENTAYDOS;
        System.out.println(c1);
        System.out.println(c2);

         */
        /*
        System.out.println(Colores.randomColores());
        System.out.println(Tallas.randomTallas());

         */
        //Calcetin.crearCalcetin();
        CajonCalcetines.creadorCalcetines();


    }

}

