package ej3;

import ej4.LecturaJSON;
import ej4.Tiempo;
import ej5.Metodos;

import java.util.HashMap;
import java.util.Iterator;

public class Prueba {
    public static void main(String[] args) {



    }
}
